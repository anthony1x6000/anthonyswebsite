Cookie Clicker
=============

<img src="img/perfectCookie.png" width="50px" height="50px">

The original game can be found at http://orteil.dashnet.org/cookieclicker/

This is for EDUCATIONAL PORPUSES

Download a copy of this if you want to "educate/see how it works" yourself offline, or go to http://ozh.github.io/cookieclicker/ if you cannot "educate" yourself on the original URL.

Github.io link:
https://bit.ly/2WgBGMj
or
https://anthony1x6000.github.io/YW50aG9ueXNjb29raWVjbGlja2Vy/

Remember this is FAIR USE and EDUCATIONAL...
Yes it is...
