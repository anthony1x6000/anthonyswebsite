This program converts standard PC text files to .8XP format to be viewed on a
TI-83/84+ calculator. To view it, edit it like a basic program.

It can be useful for storing formulas, notes, etc for use in class or
elsewhere.

You can run it either by dragging your desired file(s) into calc.exe, or from the
command line:
calc <file1> <file2>

This program supports both upper and lower case, numbers, and most (but not all)
punctuation. Characters that are not supported are replaced with a period.

The file size is limited by the calculator's RAM, usually about 24k. Lowercase
characters take up twice as much space as normal characters.

Hopefully somebody will find some use to this.

